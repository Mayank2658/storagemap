package com.mayank.storagemap

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.io.File

val SAFE_DIRS = setOf("cache", ".cache", ".thumbnails", "thumbnails", ".trash", ".trashed", ".tmp")
val SAFE_EXT = setOf("apk", "tmp", "temp")
val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm")
val REVIEW_DIRS = setOf("download", "movies", "whatsapp", "dcim", "pictures", "telegram")

fun isSafe(f: File): Boolean =
    if (f.isDirectory) f.name.lowercase() in SAFE_DIRS else f.extension.lowercase() in SAFE_EXT

fun catOf(f: File): Int = when {
    isSafe(f) -> 2
    f.isDirectory -> if (f.name.lowercase() in REVIEW_DIRS) 1 else 0
    f.extension.lowercase() in VIDEO_EXT || f.length() > 100L * 1024 * 1024 -> 1
    else -> 0
}

fun isLink(f: File): Boolean = try {
    f.canonicalFile.parentFile != f.parentFile?.canonicalFile
} catch (e: Exception) { true }

fun sizeOf(f: File): Long {
    if (!f.isDirectory) return f.length()
    if (isLink(f)) return 0L
    var s = 0L
    f.listFiles()?.forEach { s += sizeOf(it) }
    return s
}

class MainActivity : Activity() {
    private val root: File = Environment.getExternalStorageDirectory()
    private var cur: File = root
    private var token = 0
    private var asked = false
    private lateinit var info: TextView
    private lateinit var pathTv: TextView
    private lateinit var bar: ProgressBar
    private lateinit var map: TreemapView
    private lateinit var delBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF121212.toInt())
            setPadding(dp(8), dp(36), dp(8), dp(8))
        }
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val legend = TextView(this).apply {
            text = "🟩 Safe to delete   🟧 Sochke delete karo   🟦 Baaki\nTap = andar jao / file select  •  Long press = select"
            setTextColor(0xFFBBBBBB.toInt()); textSize = 11f
        }
        pathTv = TextView(this).apply { setTextColor(0xFF8AB4F8.toInt()); textSize = 13f }
        map = TreemapView(this)
        map.onTap = { item ->
            val f = item.file
            if (f != null) {
                if (item.isDir) { cur = f; map.selected.clear(); scan() } else toggle(f)
            }
        }
        map.onLong = { item -> item.file?.let { toggle(it) } }

        val row = LinearLayout(this)
        fun addBtn(t: String, f: () -> Unit): Button {
            val bt = Button(this)
            bt.text = t; bt.textSize = 11f
            bt.setOnClickListener { f() }
            row.addView(bt, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            return bt
        }
        addBtn("⚡ Safe Clean") { safeClean() }
        delBtn = addBtn("Delete selected") { deleteSelected() }
        addBtn("Apps cache") { openCache() }

        lay.addView(info)
        lay.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        lay.addView(legend)
        lay.addView(pathTv)
        lay.addView(map, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        lay.addView(row)
        setContentView(lay)
    }

    override fun onResume() {
        super.onResume()
        if (hasAccess()) scan()
        else if (!asked) { asked = true; askAccess() }
        else info.text = "Permission nahi mili. Settings me 'All files access' ON karo, phir app wapas kholo."
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val p = cur.parentFile
        if (cur != root && p != null) { cur = p; map.selected.clear(); scan() } else super.onBackPressed()
    }

    private fun toggle(f: File) {
        if (!map.selected.add(f)) map.selected.remove(f)
        map.invalidate(); updateDel()
    }

    private fun updateDel() {
        val sel = map.selected
        val s = map.items.filter { it.file != null && sel.contains(it.file) }.sumOf { it.size }
        delBtn.text = if (sel.isEmpty()) "Delete selected" else "Delete (${sel.size}) ${fmt(s)}"
    }

    private fun updateHeader() {
        val sf = StatFs(root.path)
        val total = sf.totalBytes; val free = sf.availableBytes
        info.text = "Used ${fmt(total - free)} / ${fmt(total)}   •   Free ${fmt(free)}"
        bar.progress = if (total > 0) ((total - free) * 100 / total).toInt() else 0
        pathTv.text = "📂 " + cur.path.replace(root.path, "Internal")
    }

    private fun scan() {
        val my = ++token
        val dir = cur
        info.text = "Scan ho raha hai..."
        Thread {
            val all = (dir.listFiles() ?: emptyArray())
                .map { f -> Item(f, f.name, sizeOf(f), f.isDirectory, catOf(f)) }
                .filter { it.size > 0 }.sortedByDescending { it.size }
            val top = all.take(40).toMutableList()
            val rest = all.drop(40)
            if (rest.isNotEmpty()) top.add(Item(null, "Others (${rest.size})", rest.sumOf { it.size }, false, 0))
            val sorted = top.sortedByDescending { it.size }
            runOnUiThread {
                if (my == token) { map.items = sorted; updateHeader(); updateDel() }
            }
        }.start()
    }

    private fun confirm(title: String, msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Haan, delete") { _, _ -> ok() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun deleteAll(list: List<File>) {
        info.text = "Delete ho raha hai..."
        Thread {
            var fail = 0
            list.forEach { if (!it.deleteRecursively()) fail++ }
            runOnUiThread {
                toast("Ho gaya ✅" + if (fail > 0) " ($fail items delete nahi hue)" else "")
                map.selected.clear(); scan()
            }
        }.start()
    }

    private fun deleteSelected() {
        val l = map.selected.toList()
        if (l.isEmpty()) { toast("Pehle file/folder pe long-press karke select karo"); return }
        val s = map.items.filter { it.file != null && map.selected.contains(it.file) }.sumOf { it.size }
        confirm("Delete", "${l.size} items (${fmt(s)}) permanently delete honge. Pakka?") { deleteAll(l) }
    }

    private fun collect(d: File, out: MutableList<File>) {
        val l = d.listFiles() ?: return
        for (f in l) {
            if (isSafe(f)) out.add(f) else if (f.isDirectory && !isLink(f)) collect(f, out)
        }
    }

    private fun safeClean() {
        info.text = "Safe files dhoond raha hu..."
        Thread {
            val out = ArrayList<File>()
            collect(root, out)
            val total = out.sumOf { sizeOf(it) }
            runOnUiThread {
                updateHeader()
                if (out.isEmpty()) { toast("Kuch safe-to-delete nahi mila ✅"); return@runOnUiThread }
                confirm("⚡ Safe Clean", "${out.size} items (cache, thumbnails, purani APK files) = ${fmt(total)} free honge. Delete karu?") { deleteAll(out) }
            }
        }.start()
    }

    private fun openCache() {
        toast("Settings me app chuno → Storage → Clear cache")
        try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}
