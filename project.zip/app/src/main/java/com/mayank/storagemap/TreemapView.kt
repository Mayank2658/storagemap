package com.mayank.storagemap

import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import java.io.File

class Item(val file: File?, val name: String, val size: Long, val isDir: Boolean, val cat: Int)

fun fmt(b: Long): String = when {
    b >= 1L shl 30 -> String.format("%.1f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format("%.0f MB", b / 1048576.0)
    else -> "${b / 1024} KB"
}

class TreemapView(ctx: Context) : View(ctx) {
    var items: List<Item> = emptyList()
        set(v) { field = v; rects.clear(); invalidate() }
    val selected = mutableSetOf<File>()
    var onTap: ((Item) -> Unit)? = null
    var onLong: ((Item) -> Unit)? = null

    private val rects = ArrayList<Pair<Item, RectF>>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.RED }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val base = intArrayOf(0xFF2F6FB5.toInt(), 0xFFE08A1E.toInt(), 0xFF2E9E5B.toInt())

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean { hit(e)?.let { onTap?.invoke(it) }; return true }
        override fun onLongPress(e: MotionEvent) { hit(e)?.let { onLong?.invoke(it) } }
    })

    private fun hit(e: MotionEvent): Item? = rects.firstOrNull { it.second.contains(e.x, e.y) }?.first

    override fun onTouchEvent(e: MotionEvent): Boolean = gd.onTouchEvent(e)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { rects.clear() }

    private fun layout(list: List<Item>, r: RectF) {
        if (list.isEmpty()) return
        if (list.size == 1) { rects.add(list[0] to r); return }
        val total = list.sumOf { it.size }.toDouble()
        var acc = 0.0
        var k = 0
        while (k < list.size - 1 && acc + list[k].size <= total / 2) { acc += list[k].size; k++ }
        if (k == 0) { acc = list[0].size.toDouble(); k = 1 }
        val frac = (acc / total).toFloat()
        val a = list.subList(0, k)
        val b = list.subList(k, list.size)
        if (r.width() >= r.height()) {
            val x = r.left + r.width() * frac
            layout(a, RectF(r.left, r.top, x, r.bottom)); layout(b, RectF(x, r.top, r.right, r.bottom))
        } else {
            val y = r.top + r.height() * frac
            layout(a, RectF(r.left, r.top, r.right, y)); layout(b, RectF(r.left, y, r.right, r.bottom))
        }
    }

    override fun onDraw(c: Canvas) {
        if (rects.isEmpty() && items.isNotEmpty() && width > 0) layout(items, RectF(0f, 0f, width.toFloat(), height.toFloat()))
        val max = (items.maxOfOrNull { it.size } ?: 1L).toDouble()
        val d = resources.displayMetrics.density
        tp.textSize = 12 * d
        stroke.strokeWidth = 4 * d
        val hsv = FloatArray(3)
        for ((item, r0) in rects) {
            val r = RectF(r0.left + 1.5f, r0.top + 1.5f, r0.right - 1.5f, r0.bottom - 1.5f)
            Color.colorToHSV(base[item.cat], hsv)
            hsv[2] = (0.40 + 0.60 * Math.sqrt(item.size / max)).toFloat().coerceAtMost(1f)
            fill.color = Color.HSVToColor(hsv)
            c.drawRect(r, fill)
            if (item.file != null && selected.contains(item.file)) c.drawRect(r.left + 2 * d, r.top + 2 * d, r.right - 2 * d, r.bottom - 2 * d, stroke)
            if (r.width() > 60 * d && r.height() > 34 * d) {
                c.save(); c.clipRect(r)
                c.drawText((if (item.isDir) "▸ " else "") + item.name, r.left + 6 * d, r.top + 16 * d, tp)
                c.drawText(fmt(item.size), r.left + 6 * d, r.top + 32 * d, tp)
                c.restore()
            }
        }
    }
}
